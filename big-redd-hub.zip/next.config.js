module.exports = {
  reactStrictMode: true,
}
