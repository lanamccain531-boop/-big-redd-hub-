import { useState } from 'react';

export default function Home() {
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (input.trim()) {
      setMessages([...messages, { text: input, from: 'customer' }]);
      setInput("");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-gray-900 text-white p-4 text-center text-2xl font-bold">
        Big Redd Hub
      </header>

      <main className="flex-1 p-6">
        <h1 className="text-3xl font-bold mb-4">Latest iPhones Available</h1>
        <p className="mb-4">We sell brand new, refurbished, and UK used iPhones. Delivery available — or I can personally bring it if you’re nearby.</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[7,8,10,11,12,13,14,15,16,17].map((num) => (
            <div key={num} className="bg-white shadow p-2 rounded-lg flex flex-col items-center">
              <img src={`/images/iphone${num}.jpg`} alt={`iPhone ${num}`} className="h-40 object-contain mb-2" />
              <p className="font-semibold">iPhone {num}</p>
              <button
                onClick={() => setChatOpen(true)}
                className="mt-2 px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700"
              >
                Buy Now
              </button>
            </div>
          ))}
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-bold">Contact Us</h2>
          <p>Phone: <a href="tel:0534645296" className="text-blue-600">0534645296</a></p>
          <p>Email: <a href="mailto:Ricchredd19@gmail.com" className="text-blue-600">Ricchredd19@gmail.com</a></p>
          <a href="https://wa.me/233534645296" target="_blank" rel="noopener noreferrer" className="inline-block mt-2 px-4 py-2 bg-green-500 text-white rounded-lg">
            Chat on WhatsApp
          </a>
        </div>
      </main>

      {chatOpen && (
        <div className="fixed bottom-4 right-4 w-80 bg-white shadow-lg rounded-lg border">
          <div className="p-2 bg-gray-800 text-white flex justify-between items-center">
            <span>Chat with Big Redd Hub</span>
            <button onClick={() => setChatOpen(false)}>X</button>
          </div>
          <div className="p-2 h-60 overflow-y-auto">
            {messages.map((m, i) => (
              <div key={i} className={m.from === 'customer' ? 'text-right' : 'text-left'}>
                <p className="bg-gray-200 inline-block px-2 py-1 m-1 rounded">{m.text}</p>
              </div>
            ))}
          </div>
          <div className="flex p-2 border-t">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 border px-2 py-1 rounded"
              placeholder="Type your message..."
            />
            <button onClick={handleSend} className="ml-2 px-3 py-1 bg-blue-600 text-white rounded">Send</button>
          </div>
        </div>
      )}

      <footer className="bg-gray-900 text-white text-center p-4">
        © {new Date().getFullYear()} Big Redd Hub. All rights reserved.
      </footer>
    </div>
  );
}
