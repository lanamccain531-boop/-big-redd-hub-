module.exports = {
  reactStrictMode: true,
  images: {
    unoptimized: true
  }
}
