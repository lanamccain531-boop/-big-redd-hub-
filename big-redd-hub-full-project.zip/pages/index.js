import Image from 'next/image'

export default function Home() {
  const models = [7, 8, 'X', 11, 12, 13, 14, 15, 16, '17promax']

  return (
    <div style={{ fontFamily: 'Arial', padding: '20px' }}>
      <h1>📱 Big Redd Hub</h1>
      <p>Welcome to Big Redd Hub! We sell iPhones (7 up to 17 Pro Max), both brand new, refurbished, and UK used.</p>
      <p>✅ Delivery available. We can bring it to you personally if you’re nearby.</p>

      <h2>Contact Us</h2>
      <p>📞 Phone: <a href="tel:0534645296">0534645296</a></p>
      <p>📧 Email: <a href="mailto:Ricchredd19@gmail.com">Ricchredd19@gmail.com</a></p>

      <h2>📸 Available iPhones</h2>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(150px, 1fr))', gap:'20px'}}>
        {models.map((model) => (
          <div key={model}>
            <Image 
              src={`/phones/iphone${model}.jpg`} 
              alt={`iPhone ${model}`} 
              width={200} 
              height={200} 
              style={{borderRadius:'10px'}}
            />
            <p style={{textAlign:'center'}}>iPhone {model}</p>
          </div>
        ))}
      </div>

      <button style={{padding:'10px 20px', marginTop:'20px', backgroundColor:'#d32f2f', color:'#fff', border:'none', borderRadius:'8px'}} 
        onClick={() => window.location.href='#chat'}>
        Buy Now
      </button>

      <div id="chat" style={{marginTop:'40px'}}>
        <h2>💬 Chat with Us</h2>
        <p>Click below to start chatting on WhatsApp:</p>
        <a href="https://wa.me/233534645296" target="_blank" rel="noopener noreferrer">
          <button style={{padding:'10px 20px', backgroundColor:'#25D366', color:'#fff', border:'none', borderRadius:'8px'}}>
            Chat on WhatsApp
          </button>
        </a>
      </div>
    </div>
  )
}
